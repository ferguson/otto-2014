#SAFARI="/Applications/Safari.app/Contents/MacOS/Safari"
#exec "$SAFARI" $1

open -W -a Safari $1