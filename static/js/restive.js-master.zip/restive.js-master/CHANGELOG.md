# CHANGELOG
 
 
## 1.2.0
- Solve issue with `force_dip` option not working with `breakpoints`
- Solve issue with orientation status updates when soft-keyboard is initialized on certain mobile devices
- Solve issue with `turbo_classes` not being fired when `breakpoints` do not match 


## 1.1.0
- Solve Fatal Error and Storage Issue when using Private Browsing on iOS
- Add Modularity Feature
- Update Tablet Detection Feature for even Better Detection of Tablet Devices (especially for Android)


## 1.0.0
- Initial Release 
